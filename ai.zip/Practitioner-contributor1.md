# contributor1 - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **contributor1**

## Example Practitioner: contributor1

**name**: Joyce Y C Chan 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "contributor1",
  "name" : [
    {
      "family" : "Chan",
      "given" : ["Joyce Y C"]
    }
  ]
}

```
