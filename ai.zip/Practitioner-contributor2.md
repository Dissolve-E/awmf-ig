# contributor2 - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **contributor2**

## Example Practitioner: contributor2

**name**: Hoyee W Hirai 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "contributor2",
  "name" : [
    {
      "family" : "Hirai",
      "given" : ["Hoyee W"]
    }
  ]
}

```
