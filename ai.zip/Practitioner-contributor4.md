# contributor4 - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **contributor4**

## Example Practitioner: contributor4

**name**: Timothy C Y Kwok 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "contributor4",
  "name" : [
    {
      "family" : "Kwok",
      "given" : ["Timothy C Y"]
    }
  ]
}

```
