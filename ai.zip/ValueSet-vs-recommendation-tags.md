# Recommendation Tags - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Recommendation Tags**

## ValueSet: Recommendation Tags 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.awmf.org/awmf.ig/ValueSet/vs-recommendation-tags | *Version*:0.2.0 |
| Draft as of 2026-03-19 | *Computable Name*:RecommendationTagsVS |

 
ValueSet listing different tags to use for recommendations 

 **References** 

* [Recommendation](StructureDefinition-recommendation.md)
* [Recommendation](StructureDefinition-recommendation.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R5/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "vs-recommendation-tags",
  "url" : "http://fhir.awmf.org/awmf.ig/ValueSet/vs-recommendation-tags",
  "version" : "0.2.0",
  "name" : "RecommendationTagsVS",
  "title" : "Recommendation Tags",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-03-19T10:36:56+00:00",
  "publisher" : "AWMF e.V.",
  "contact" : [{
    "name" : "AWMF e.V.",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.awmf.org"
    }]
  }],
  "description" : "ValueSet listing different tags to use for recommendations",
  "compose" : {
    "include" : [{
      "system" : "http://fhir.awmf.org/awmf.ig/CodeSystem/cs-recommendation-tags"
    }]
  }
}

```
