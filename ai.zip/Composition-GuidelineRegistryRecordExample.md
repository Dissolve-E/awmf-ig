# Guideline Registry Record Example - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Guideline Registry Record Example**

## Example Composition: Guideline Registry Record Example

Guideline Example



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "GuidelineRegistryRecordExample",
  "meta" : {
    "profile" : ["http://fhir.awmf.org/awmf.ig/StructureDefinition/guideline-registry-record"]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "https://example.org/identifiers",
    "value" : "AWMF-Guideline-Example"
  }],
  "version" : "2.0",
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://fhir.awmf.org/awmf.ig/CodeSystem/cs-awmf",
      "code" : "guideline-registry-record",
      "display" : "Guideline Registry Record"
    }]
  },
  "date" : "2025-03-06",
  "author" : [{
    "extension" : [{
      "url" : "http://fhir.awmf.org/awmf.ig/StructureDefinition/ext-guideline-author-role",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.awmf.org/awmf.ig/CodeSystem/cs-guideline-author-role",
          "code" : "registrant"
        }]
      }
    }],
    "reference" : "PractitionerRole/GuidelineAuthorRoleExample"
  }],
  "title" : "Example Guideline",
  "relatesTo" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/relatesto-classifier",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://fhir.awmf.org/awmf.ig/CodeSystem/cs-related-artifact-types",
          "code" : "related-guideline"
        }]
      }
    }],
    "type" : "similar-to",
    "targetReference" : {
      "reference" : "Composition/GuidelineExample"
    }
  }]
}

```
