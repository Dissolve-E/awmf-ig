# contributor3 - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **contributor3**

## Example Practitioner: contributor3

**name**: Samuel Y S Wong 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "contributor3",
  "name" : [
    {
      "family" : "Wong",
      "given" : ["Samuel Y S"]
    }
  ]
}

```
