# PICO Outcome Specificity of Recommendation 17 from Guideline 038-013 - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PICO Outcome Specificity of Recommendation 17 from Guideline 038-013**

## Example Group: PICO Outcome Specificity of Recommendation 17 from Guideline 038-013

Profile: [Conceptual Cohort Definition Outcome](StructureDefinition-conceptual-cohort-definition-outcome.md)

**description**: 

Spezifizität für die Indikation einer Demenz

**membership**: Conceptual

**code**: Outcome



## Resource Content

```json
{
  "resourceType" : "Group",
  "id" : "PICOOutcomeSpecificityRec17",
  "meta" : {
    "profile" : ["http://fhir.awmf.org/awmf.ig/StructureDefinition/conceptual-cohort-definition-outcome"]
  },
  "description" : "Spezifizität für die Indikation einer Demenz",
  "membership" : "conceptual",
  "code" : {
    "coding" : [{
      "system" : "http://fhir.awmf.org/awmf.ig/CodeSystem/cs-pico",
      "code" : "outcome"
    }]
  }
}

```
