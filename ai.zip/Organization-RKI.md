# Robert Koch-Institut - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Robert Koch-Institut**

## Example Organization: Robert Koch-Institut

Robert Koch-Institut (RKI)



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "RKI",
  "name" : "Robert Koch-Institut (RKI)"
}

```
