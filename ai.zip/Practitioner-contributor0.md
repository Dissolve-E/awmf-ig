# contributor0 - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **contributor0**

## Example Practitioner: contributor0

**name**: Kelvin K F Tsoi 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "contributor0",
  "name" : [
    {
      "family" : "Tsoi",
      "given" : ["Kelvin K F"]
    }
  ]
}

```
