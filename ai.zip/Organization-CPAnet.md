# Netzwerk chronisch pulmonale Aspergillose (CPAnet) - Dissolve-E: AWMF Guideline Registry v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Netzwerk chronisch pulmonale Aspergillose (CPAnet)**

## Example Organization: Netzwerk chronisch pulmonale Aspergillose (CPAnet)

Netzwerk chronisch pulmonale Aspergillose (CPAnet)



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "CPAnet",
  "name" : "Netzwerk chronisch pulmonale Aspergillose (CPAnet)"
}

```
